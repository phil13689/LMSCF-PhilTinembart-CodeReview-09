1. Query:
SELECT COUNT(*)FROM employee
Result: 3

2. Query:
SELECT COUNT(*) FROM `customer` WHERE first_name='Don' 
Result: 1

3.Query:
SELECT SUM(parcel.weight) FROM parcel
Result: SUM(parcel.weight) 9

4.Querry:
SELECT AVG (check_number) FROM billing
Result: 3777.3333

5.Query:
SELECT SUM(details.salary) FROM details
Result: 10500

6.Query:
SELECT AVG(details.salary) FROM details
Result: 3500