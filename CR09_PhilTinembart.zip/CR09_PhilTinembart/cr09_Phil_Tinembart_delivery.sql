-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 14. Mrz 2020 um 17:47
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `codereview`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `billing`
--

CREATE TABLE `billing` (
  `billing_ID` int(10) NOT NULL,
  `check_number` int(10) DEFAULT NULL,
  `amount` int(10) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `fk_customer_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `billing`
--

INSERT INTO `billing` (`billing_ID`, `check_number`, `amount`, `payment_date`, `fk_customer_id`) VALUES
(1, 2343, 400, '0000-00-00', NULL),
(2, 3434, 600, '2005-01-23', NULL),
(3, 5555, 1233, '2005-01-31', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(10) NOT NULL,
  `first_name` varchar(40) DEFAULT NULL,
  `last_name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `customer`
--

INSERT INTO `customer` (`customer_id`, `first_name`, `last_name`) VALUES
(1, 'Foo', 'Manchoo'),
(2, 'Don', 'Draper'),
(3, 'John', 'Cosgrove');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `date`
--

CREATE TABLE `date` (
  `date_id` int(10) NOT NULL,
  `delivery_date` date DEFAULT NULL,
  `recieve_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `date`
--

INSERT INTO `date` (`date_id`, `delivery_date`, `recieve_date`) VALUES
(1, '2005-10-05', '2005-10-07'),
(2, '2005-10-05', '2005-10-07'),
(3, '2005-10-05', '2005-10-07');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `details`
--

CREATE TABLE `details` (
  `details_id` int(10) NOT NULL,
  `salary` int(10) DEFAULT NULL,
  `fk_employee_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `details`
--

INSERT INTO `details` (`details_id`, `salary`, `fk_employee_id`) VALUES
(1, 4500, NULL),
(2, 5000, NULL),
(3, 1000, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(10) NOT NULL,
  `first_name` varchar(40) DEFAULT NULL,
  `last_name` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `employee`
--

INSERT INTO `employee` (`employee_id`, `first_name`, `last_name`) VALUES
(1, 'James', 'Branson'),
(2, 'Michael', 'Scott'),
(3, 'Dwight', 'Schrute');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `location`
--

CREATE TABLE `location` (
  `location_id` int(10) NOT NULL,
  `street` varchar(60) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `zip` int(10) DEFAULT NULL,
  `fk_customer_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `location`
--

INSERT INTO `location` (`location_id`, `street`, `city`, `zip`, `fk_customer_id`) VALUES
(1, 'dwevvwdvw', 'ddfef', 34343, NULL),
(2, 'teafvd', 'hzgefwsd', 5433, NULL),
(3, 'nhbgv', 'lokihzg', 9876, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `parcel`
--

CREATE TABLE `parcel` (
  `parcel_id` int(10) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  `fk_date_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `parcel`
--

INSERT INTO `parcel` (`parcel_id`, `weight`, `fk_date_id`) VALUES
(1, 5, NULL),
(2, 3, NULL),
(3, 1, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `process`
--

CREATE TABLE `process` (
  `process_id` int(10) NOT NULL,
  `fk_parcel_id` int(10) DEFAULT NULL,
  `fk_employee_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `process`
--

INSERT INTO `process` (`process_id`, `fk_parcel_id`, `fk_employee_id`) VALUES
(1, NULL, NULL),
(2, NULL, NULL),
(3, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `receive`
--

CREATE TABLE `receive` (
  `receive_id` int(10) NOT NULL,
  `fk_customer_id` int(10) DEFAULT NULL,
  `fk_parcel_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `receive`
--

INSERT INTO `receive` (`receive_id`, `fk_customer_id`, `fk_parcel_id`) VALUES
(1, NULL, NULL),
(2, NULL, NULL),
(3, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `shipping`
--

CREATE TABLE `shipping` (
  `shipping_id` int(10) NOT NULL,
  `fk_parcel_id` int(10) DEFAULT NULL,
  `fk_customer_id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `shipping`
--

INSERT INTO `shipping` (`shipping_id`, `fk_parcel_id`, `fk_customer_id`) VALUES
(1, NULL, NULL),
(2, NULL, NULL),
(3, NULL, NULL);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `billing`
--
ALTER TABLE `billing`
  ADD PRIMARY KEY (`billing_ID`),
  ADD KEY `fk_customer_id` (`fk_customer_id`);

--
-- Indizes für die Tabelle `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indizes für die Tabelle `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`date_id`);

--
-- Indizes für die Tabelle `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`details_id`),
  ADD KEY `fk_employee_id` (`fk_employee_id`);

--
-- Indizes für die Tabelle `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indizes für die Tabelle `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`),
  ADD KEY `fk_customer_id` (`fk_customer_id`);

--
-- Indizes für die Tabelle `parcel`
--
ALTER TABLE `parcel`
  ADD PRIMARY KEY (`parcel_id`),
  ADD KEY `fk_date_id` (`fk_date_id`);

--
-- Indizes für die Tabelle `process`
--
ALTER TABLE `process`
  ADD PRIMARY KEY (`process_id`),
  ADD KEY `fk_parcel_id` (`fk_parcel_id`),
  ADD KEY `fk_employee_id` (`fk_employee_id`);

--
-- Indizes für die Tabelle `receive`
--
ALTER TABLE `receive`
  ADD PRIMARY KEY (`receive_id`),
  ADD KEY `fk_customer_id` (`fk_customer_id`),
  ADD KEY `fk_parcel_id` (`fk_parcel_id`);

--
-- Indizes für die Tabelle `shipping`
--
ALTER TABLE `shipping`
  ADD PRIMARY KEY (`shipping_id`),
  ADD KEY `fk_parcel_id` (`fk_parcel_id`),
  ADD KEY `fk_customer_id` (`fk_customer_id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `billing`
--
ALTER TABLE `billing`
  MODIFY `billing_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `date`
--
ALTER TABLE `date`
  MODIFY `date_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `details`
--
ALTER TABLE `details`
  MODIFY `details_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `employee`
--
ALTER TABLE `employee`
  MODIFY `employee_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `parcel`
--
ALTER TABLE `parcel`
  MODIFY `parcel_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `process`
--
ALTER TABLE `process`
  MODIFY `process_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `receive`
--
ALTER TABLE `receive`
  MODIFY `receive_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `shipping`
--
ALTER TABLE `shipping`
  MODIFY `shipping_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `billing`
--
ALTER TABLE `billing`
  ADD CONSTRAINT `billing_ibfk_1` FOREIGN KEY (`fk_customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints der Tabelle `details`
--
ALTER TABLE `details`
  ADD CONSTRAINT `details_ibfk_1` FOREIGN KEY (`fk_employee_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints der Tabelle `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `location_ibfk_1` FOREIGN KEY (`fk_customer_id`) REFERENCES `customer` (`customer_id`);

--
-- Constraints der Tabelle `parcel`
--
ALTER TABLE `parcel`
  ADD CONSTRAINT `parcel_ibfk_1` FOREIGN KEY (`fk_date_id`) REFERENCES `date` (`date_id`);

--
-- Constraints der Tabelle `process`
--
ALTER TABLE `process`
  ADD CONSTRAINT `process_ibfk_1` FOREIGN KEY (`fk_parcel_id`) REFERENCES `parcel` (`parcel_id`),
  ADD CONSTRAINT `process_ibfk_2` FOREIGN KEY (`fk_employee_id`) REFERENCES `employee` (`employee_id`);

--
-- Constraints der Tabelle `receive`
--
ALTER TABLE `receive`
  ADD CONSTRAINT `receive_ibfk_1` FOREIGN KEY (`fk_customer_id`) REFERENCES `customer` (`customer_id`),
  ADD CONSTRAINT `receive_ibfk_2` FOREIGN KEY (`fk_parcel_id`) REFERENCES `parcel` (`parcel_id`);

--
-- Constraints der Tabelle `shipping`
--
ALTER TABLE `shipping`
  ADD CONSTRAINT `shipping_ibfk_1` FOREIGN KEY (`fk_parcel_id`) REFERENCES `parcel` (`parcel_id`),
  ADD CONSTRAINT `shipping_ibfk_2` FOREIGN KEY (`fk_customer_id`) REFERENCES `customer` (`customer_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
